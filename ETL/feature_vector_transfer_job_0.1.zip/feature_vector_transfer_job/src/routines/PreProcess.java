package routines;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class PreProcess {

	public static void replaceCharAt(String filePath, int index, char c) throws FileNotFoundException, IOException {
		File f = new File(filePath);
		int fileLength = (int) f.length();
		
		if (index < 0 || index > fileLength - 1) {
		    throw new IllegalArgumentException("Invalid index " + index);
		}
		
		byte[] bt = new byte[(int) fileLength];
		FileInputStream fis = new FileInputStream(f);
		fis.read(bt);
		StringBuffer sb = new StringBuffer(new String(bt));
		
		//sb.setCharAt(index, '');
		sb.setCharAt(index, c);
		
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(sb.toString().getBytes());
		fos.close();
	}
	
	public static void deleteCharAt(String filePath, int index) throws FileNotFoundException, IOException {
		File f = new File(filePath);
		int fileLength = (int) f.length();
		
		if (index < 0 || index > fileLength - 1) {
		    throw new IllegalArgumentException("Invalid index " + index);
		}
		
		byte[] bt = new byte[(int) fileLength];
		FileInputStream fis = new FileInputStream(f);
		fis.read(bt);
		StringBuffer sb = new StringBuffer(new String(bt));
		
		//sb.setCharAt(index, '');
		sb.deleteCharAt(index);
		
		FileOutputStream fos = new FileOutputStream(f);
		fos.write(sb.toString().getBytes());
		fos.close();
	}
	
	public static String executeCommand(String command)
	{
		StringBuffer output = new StringBuffer();
		 
		Process p;
		try {
			System.out.println("In Command Exceute.");
			p = Runtime.getRuntime().exec(command);
			p.waitFor();
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
			}
			System.out.println("Out Command Exceute: "+output);
		} catch (Exception e) {
			e.printStackTrace();
		}
 
		return output.toString();
	}
	
	public static void createFlagFile(String filePath)
	{
		File writeFile = new File(filePath);
		
		try{
			// if file doesn't exists, then create it
			if (!writeFile.exists()) 
				writeFile.createNewFile();
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void createFile(String filePath)
	{
		File writeFile = new File(filePath);
		
		try{
			// if file doesn't exists, then create it
			if (!writeFile.exists()) 
				writeFile.createNewFile();
					
		    FileWriter fw = new FileWriter(writeFile.getAbsoluteFile(),true);
			BufferedWriter bw = new BufferedWriter(fw);
			
			bw.write("1,rootid,cli,dnis,skillgroup,vq_sct,callstarttime,callendtime,callhandletime,callwraptime,agentid");
			bw.write("\n");
			bw.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void convertToDAT(String filePath, String writePath){
		File readFile = new File(filePath);
		File writeFile = new File(writePath);
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		char unit_separator = 0x1F;
		
		try{
			fis = new FileInputStream(readFile);

		    // Here BufferedInputStream is added for fast reading.
		    bis = new BufferedInputStream(fis);
		    dis = new DataInputStream(bis);
		      
		 // if file doesn't exists, then create it
			if (!writeFile.exists()) 
				writeFile.createNewFile();
					
		    FileWriter fw = new FileWriter(writeFile.getAbsoluteFile(),true);
			BufferedWriter bw = new BufferedWriter(fw);

		    // dis.available() returns 0 if the file does not have more lines.
		    while (dis.available() != 0) {

		    	//System.out.println(dis.readLine().toString());
		    	String x = dis.readLine().toString();
		    	
		    	//x.replaceAll(",", ";;");
		    	x = x.replaceAll(",", Character.toString(unit_separator));
		    	x = x.replaceAll("\"", "");
		    	
		    	//System.out.println(x);
				bw.write(x);
				bw.write("\n");
				//System.out.println(line);
		    }

			// dispose all the resources after using them.
		    fis.close();
		    bis.close();
		    dis.close();
		    bw.close();

		}
		catch(Exception e)
		{
			
		}
		
	}
	
	public static void preprocess(String readFilePath, String writeFilePath){

		//System.out.println("------------------------------------------------------------------------------------");
		//System.out.println(readFilePath);
		//System.out.println(writeFilePath);
		//System.out.println("------------------------------------------------------------------------------------");
		File readFile = new File(readFilePath);
		File writeFile = new File(writeFilePath);
		        
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		DataInputStream dis = null;
		String line;
		char unit_separator = 0x1F;

		try 
		{
			fis = new FileInputStream(readFile);

		    // Here BufferedInputStream is added for fast reading.
		    bis = new BufferedInputStream(fis);
		    dis = new DataInputStream(bis);
		      
		    // if file doesn't exists, then create it
			if (!writeFile.exists()) 
				writeFile.createNewFile();
					
		    FileWriter fw = new FileWriter(writeFile.getAbsoluteFile(),true);
			BufferedWriter bw = new BufferedWriter(fw);

		    // dis.available() returns 0 if the file does not have more lines.
		    while (dis.available() != 0) {

		    	//System.out.println(dis.readLine().toString());
		    	//String x = dis.readLine().toString();
		    	
		    	//System.out.println(x);
		    	
				line = "";
		    	String [] tokens = dis.readLine().split(Character.toString(unit_separator), -1);
		    	
		    	if(tokens[0].equals("1") || tokens[0].equals("4"))
		    		continue;
		    	
		    	for (int i = 0 ; i < tokens.length ; i++){
		    		line = line + tokens[i].trim() + ",";
		    	}
				
		    	line = line.substring(0, line.length()-1) + "\n";	
				bw.write(line);
				//System.out.println(line);
		    }

			// dispose all the resources after using them.
		    fis.close();
		    bis.close();
		    dis.close();
		    bw.close();
		} 

		catch (Exception e) 
		{
			e.printStackTrace();
		}

	}
	
	
	
    public static void helloExample(String message) {
        if (message == null) {
            message = "World"; //$NON-NLS-1$
        }
        System.out.println("Hello " + message + " !"); //$NON-NLS-1$ //$NON-NLS-2$
    }
}
